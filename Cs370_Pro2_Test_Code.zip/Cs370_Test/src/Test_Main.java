
public class Test_Main {
	public static void main(String args[]) {
		
	    new GUI();
        new Interact();
	  }

}
