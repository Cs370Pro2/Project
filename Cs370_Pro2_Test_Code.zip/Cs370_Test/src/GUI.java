import javax.swing.JFrame;

public class GUI extends JFrame {
	public GUI() {
		setTitle ("Airline GUI 1");
        setSize (500, 500);
        setLocation (400, 100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);	
        
		
	}

}
